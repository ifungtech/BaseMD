let handler = async (m, { conn }) => {
  let wait = 'Please wait...';

  const arr = [
    { text: "  ╚═╝", timeout: 500 },
    { text: "  ██╗\n╚═╝", timeout: 1000 },
    { text: "╚══╝\n██╗\n╚═╝", timeout: 1500 },
    { text: "╚═╝███╔╝\n╚══╝\n██╗\n╚═╝", timeout: 2000 },
    { text: "██╔══██╗\n╚═╝███╔╝\n╚══╝\n██╗\n╚═╝", timeout: 2500 },
    { text: " ░█████╗\n██╔══██╗\n╚═╝███╔╝\n╚══╝\n██╗\n╚═╝", timeout: 3000 },
    { text: "*😂*", timeout: 3500 }
  ];

  const lll = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });

  for (let i = 0; i < arr.length; i++) {
    await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
    await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: lll,
        type: 14,
        editedMessage: {
          conversation: arr[i].text
        }
      }
    }, {});
  }
};
handler.help = ['hallo']
handler.customPrefix = /^(hallo)$/i
handler.command = new RegExp
module.exports = handler;