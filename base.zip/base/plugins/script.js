let handler = async (m, { conn, usedPrefix: _p, __dirname, args }) => {
conn.relayMessage(m.chat, {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: 25000000,
      requestFrom: m.sender,
      noteMessage: {
        extendedTextMessage: {
          text: `Apa ngabs`,
          contextInfo: {
            mentionedJid: [creator],
            externalAdReply: {
              showAdAttribution: true
            }
          }
        }
      }
    }
  }, {})
}
handler help = ['woy']
handler.customPrefix = /^(tes min)$/i
handler.command = new RegExp
handler.owner = true

module.exports = handler